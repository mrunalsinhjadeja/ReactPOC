export const PtwoChildone: React.FC = () => {
  return (
    <div className="mb-3 card">
      <div className="bg-body-tertiary card-body">Parent two Child one</div>
    </div>
  );
};
