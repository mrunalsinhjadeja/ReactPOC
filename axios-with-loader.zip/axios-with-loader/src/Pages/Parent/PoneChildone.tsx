export const PoneChildone: React.FC = () => {
  return (
    <div className="mb-3 card">
      <div className="bg-body-tertiary card-body">Parent one Child one</div>
    </div>
  );
};
