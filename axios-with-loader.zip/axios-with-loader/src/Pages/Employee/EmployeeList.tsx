import { IEmployeeList } from "../../Models/Employee";
import Table from "react-bootstrap/Table";
import SkeletonTable from "../../Component/Skeleton/SkeletonTable";

export const EmployeeList = (props: {
  EmpTableList: any;
  isLoading: boolean;
}) => {
  const { EmpTableList, isLoading } = props;

  return (
    <div className="table-container">
      <Table responsive>
        <thead>
          <tr>
            <th>Name</th>
            <th>Active</th>
            <th>Birthday</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {isLoading ? (
            <SkeletonTable Column={3} Row={10} />
          ) : (
            EmpTableList?.map((d: IEmployeeList, index: number) => {
              return (
                <tr key={index}>
                  <td>{d.name}</td>
                  <td>{d.isActive ? "Active" : "Inactive"}</td>
                  <td>{d.birthday}</td>
                  <td>&nbsp;</td>
                </tr>
              );
            })
          )}
        </tbody>
      </Table>
    </div>
  );
};
