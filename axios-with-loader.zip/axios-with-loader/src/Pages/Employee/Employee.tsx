import { useEffect, useState } from "react";
import { IEmployeeList } from "../../Models/Employee";
import { EmployeeList } from "./EmployeeList";
import { EmployeeService } from "./EmployeeServices";
import Button from "react-bootstrap/Button";
import { useDispatch, useSelector } from "react-redux";
import { trackRefreshCount } from "../../Redux/RefreshCount/slice";

export const Employee: React.FC = () => {
  const getEmployeesList = EmployeeService();
  let loaded = false;
  const [empTblList, setEmpTblList] = useState<IEmployeeList[]>([]);
  const dispatch = useDispatch();

  const isEmployeeListLoading: boolean = useSelector(
    (state: any) => state.employeeLoaderSlice.isEmployeeListLoading
  );

  const btnRefreshCountText: string = useSelector(
    (state: any) => state.employeeLoaderSlice.BtnRefreshText
  );

  const refreshCount: number = useSelector(
    (state: any) => state.trackRefreshCountSlice.refreshCount
  );

  useEffect(() => {
    (async () => {
      if (!loaded) {
        var employeeList = await SetEmployeeList();
        setEmpTblList(employeeList);
      }
    })();
  }, []);

  const SetEmployeeList = async () => {
    loaded = true;
    return await getEmployeesList();
  };
  return (
    <div>
      <div>
        <Button
          disabled={isEmployeeListLoading}
          variant="primary"
          onClick={() => {
            dispatch(trackRefreshCount());
            SetEmployeeList();
          }}
        >
          {btnRefreshCountText} ({refreshCount})
        </Button>

        <EmployeeList
          EmpTableList={empTblList}
          isLoading={isEmployeeListLoading}
        />
      </div>
    </div>
  );
};
