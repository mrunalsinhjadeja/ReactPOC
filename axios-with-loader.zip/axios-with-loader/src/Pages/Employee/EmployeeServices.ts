import { HttpGet } from "../../Helpers/HttpClient";
import CONSTANT_LOAD from "../../Helpers/LoadingConstants";

export const EmployeeService = () => {
  const httpGet = HttpGet();
  const getEmployeesList: any = async () => {
    try {
      const response = await httpGet(
        "uow",
        CONSTANT_LOAD.TOGGLE_EMPLOYEE_LIST_LOADER
      );
      return response.data;
    } catch (error) {
      console.log(error);
    }
  };
  return getEmployeesList;
};

// export const EmployeeService = () => {
//   const axiosClient = useAxios();
//   const getEmployeesList: any = async () => {
//     try {
//       const response = await axiosClient.get("uow", {
//         headers: { custom_loader: CONSTANT_LOAD.TOGGLE_FULL_SCREEN_LOADER },
//       });
//       return response.data;
//     } catch (error) {
//       console.log(error);
//     }
//   };
//   return getEmployeesList;
// };
