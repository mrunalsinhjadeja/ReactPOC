export const Dashboard: React.FC = () => {
  return (
    <div className="mb-3 card">
      <div className="card-header">
        <div className="g-2 align-items-center row">
          <div className="col">
            <div className="d-flex">
              <h5
                className="mb-0 hover-actions-trigger text-truncate text-nowrap"
                id="example"
              >
                Example
              </h5>
            </div>
          </div>
        </div>
      </div>
      <div className="bg-body-tertiary card-body">Body</div>
    </div>
  );
};
