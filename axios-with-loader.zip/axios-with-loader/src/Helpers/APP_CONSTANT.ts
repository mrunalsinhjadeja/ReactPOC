const appName = process.env.REACT_APP_NAME;
const app_configuration = {
  APP_NAME: appName,
};

export default app_configuration;
