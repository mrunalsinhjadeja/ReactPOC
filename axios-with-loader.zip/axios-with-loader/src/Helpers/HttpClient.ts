import useAxios from "./AxiosInterceptors";
import CONSTANT_LOAD from "./LoadingConstants";

export const HttpGet = () => {
  const axiosClient = useAxios();

  const get: any = async (url: string, loader: string) => {
    try {
      if (typeof loader !== "string" || !loader) {
        loader = CONSTANT_LOAD.TOGGLE_FULL_SCREEN_LOADER;
      }
      const response = await axiosClient.get(url, {
        headers: { custom_loader: loader },
      });
      return response;
    } catch (error) {
      console.log(error);
    }
  };
  return get;
};
