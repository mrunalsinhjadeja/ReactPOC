const CONSTANT_LOAD = {
  TOGGLE_FULL_SCREEN_LOADER: "loaderSlice/toggleFullScreenLoader",
  TOGGLE_EMPLOYEE_LIST_LOADER: "employeeLoaderSlice/toggleEmployeeListLoader",
};

export default CONSTANT_LOAD;
