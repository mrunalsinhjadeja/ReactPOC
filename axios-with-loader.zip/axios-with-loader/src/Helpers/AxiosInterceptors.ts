import axios from "axios";
import { useDispatch } from "react-redux";

const useAxios = () => {
  const dispatch = useDispatch();
  const axiosClient = axios.create({
    baseURL: "https://localhost:7131/api/",
  });

  axiosClient.interceptors.response.use(
    (response) => {
      dispatch({ type: response.config.headers.custom_loader });
      return response;
    },
    (error) => {
      dispatch({ type: error.config.headers.custom_loader });
      return Promise.reject(error);
    }
  );

  axiosClient.interceptors.request.use(
    (config) => {
      dispatch({ type: config.headers.custom_loader });
      config.headers["Content-Type"] = "application/json";
      return config;
    },
    (error) => {
      Promise.reject(error);
    }
  );
  return axiosClient;
};

export default useAxios;
