import { createSlice } from "@reduxjs/toolkit";

export interface LoaderState {
  isLoading: boolean;
}

const initialState: LoaderState = {
  isLoading: false,
};

export const loadSlice = createSlice({
  name: "loaderSlice",
  initialState,
  reducers: {
    toggleFullScreenLoader: (state): void => {
      state.isLoading = !state.isLoading;
    },
  },
});

export const { toggleFullScreenLoader } = loadSlice.actions;

export default loadSlice.reducer;
