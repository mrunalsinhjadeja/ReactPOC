import { createSlice } from "@reduxjs/toolkit";

export interface EmployeeListLoaderState {
  isEmployeeListLoading: boolean;
  BtnRefreshText: string;
}

const initialState: EmployeeListLoaderState = {
  isEmployeeListLoading: false,
  BtnRefreshText: "Refresh",
};

export const employeeLoaderSlice = createSlice({
  name: "employeeLoaderSlice",
  initialState,
  reducers: {
    toggleEmployeeListLoader: (state): void => {
      state.isEmployeeListLoading = !state.isEmployeeListLoading;
      state.BtnRefreshText = state.isEmployeeListLoading
        ? "Refreshing"
        : "Refresh";
    },
  },
});

export const { toggleEmployeeListLoader } = employeeLoaderSlice.actions;

export default employeeLoaderSlice.reducer;
