import { PayloadAction, createSlice } from "@reduxjs/toolkit";

export interface ToggleMenuClass {
  activeSidebarClassName: string;
  activeParentLinkIndex: number;
  activeChildLinkIndex: number;
}

const initialState: ToggleMenuClass = {
  activeSidebarClassName: "sidebar close",
  activeParentLinkIndex: 2,
  activeChildLinkIndex: 0,
};

export const commonSlice = createSlice({
  name: "commonSlice",
  initialState,
  reducers: {
    toggleSideMenu: (state): void => {
      state.activeSidebarClassName =
        state.activeSidebarClassName === "sidebar close"
          ? "sidebar"
          : "sidebar close";
    },
    setActiveParentLinkIndex: (state, action: PayloadAction<number>): void => {
      state.activeParentLinkIndex = action.payload;
    },
    setActiveChildLinkIndex: (state, action: PayloadAction<number>): void => {
      state.activeChildLinkIndex = action.payload;
    },
  },
});

export const {
  toggleSideMenu,
  setActiveParentLinkIndex,
  setActiveChildLinkIndex,
} = commonSlice.actions;

export default commonSlice.reducer;
