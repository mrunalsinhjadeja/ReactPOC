import { createSlice } from "@reduxjs/toolkit";

export interface LoaderState {
  refreshCount: number;
}

const initialState: LoaderState = {
  refreshCount: 0,
};

export const trackRefreshCountSlice = createSlice({
  name: "refreshCountSlice",
  initialState,
  reducers: {
    trackRefreshCount: (state): void => {
      state.refreshCount += 1;
    },
  },
});

export const { trackRefreshCount } = trackRefreshCountSlice.actions;

export default trackRefreshCountSlice.reducer;
