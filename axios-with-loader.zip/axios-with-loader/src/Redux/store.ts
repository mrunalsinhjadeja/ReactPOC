import { configureStore } from "@reduxjs/toolkit";
import loaderReducer from "./Loader/slice";
import employeeLoader from "./Loader/EmployeeSlice";
import trackRefreshCountSlice from "./RefreshCount/slice";
import commonState from "./Common/slice";

const store = configureStore({
  reducer: {
    loader: loaderReducer,
    trackRefreshCountSlice: trackRefreshCountSlice,
    employeeLoaderSlice: employeeLoader,
    commonSlice: commonState,
  },
});

export default store;

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
