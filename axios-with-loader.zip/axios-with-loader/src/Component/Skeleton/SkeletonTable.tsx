import Skeleton from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";
import "../../App.css";

interface TableOption {
  Column?: number;
  Row?: number;
  CellWidth?: number;
  CellHeight?: number;
}
const SkeletonTable = ({
  Column = 5,
  Row = 5,
  CellWidth = 100,
  CellHeight = 20,
}: TableOption) => {
  return (
    <tr>
      {Array.from(Array(Column), (e, i) => {
        return (
          <td key={i}>
            <div className="skeleton-table">
              <Skeleton
                className="box"
                count={Row}
                width={CellWidth}
                height={CellHeight}
              />
            </div>
          </td>
        );
      })}
    </tr>
  );
};

export default SkeletonTable;
