import { useState } from "react";
import { NavLink } from "react-router-dom";

export const UnderLinedChildItems = (props: {
  ChildrenItem: any;
  Title: string;
}) => {
  const childList = props.ChildrenItem;
  const title = props.Title;

  const [activeItem, setActiveItem] = useState(null);

  const handleToggleActiveLink = (index: any) => {
    setActiveItem(index === activeItem ? null : index);
  };
  return (
    <>
      <div className="iocn-link">
        <NavLink to="#">
          <i className="bx bx-collection"></i>
          <span className="link_name">{title}</span>
        </NavLink>
        <i className="bx bxs-chevron-down arrow"></i>
      </div>
      <ul className="sub-menu">
        <li>
          <NavLink className="link_name" to="#">
            {title}
          </NavLink>
        </li>
        {childList.map((item: any, index: any) => {
          return (
            <li key={item.name}>
              <NavLink
                className={index === activeItem ? "nav-link active" : ""}
                to={item.route}
                onClick={() => {
                  handleToggleActiveLink(index);
                }}
              >
                {item.name}
              </NavLink>
            </li>
          );
        })}
      </ul>
    </>
  );
};
