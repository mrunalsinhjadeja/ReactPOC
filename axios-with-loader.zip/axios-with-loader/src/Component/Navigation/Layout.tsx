import { Routers } from "./Routers";
import { useDispatch, useSelector } from "react-redux";
import { toggleSideMenu } from "../../Redux/Common/slice";
import { Sidebar } from "./Sidebar";
import FullScreenLoader from "../Skeleton/FullScreenLoader";

export const Layout: React.FC = (props: any) => {
  const dispatch = useDispatch();
  const isFullScreenLoading: boolean = useSelector(
    (state: any) => state.loader.isLoading
  );
  return (
    <div>
      <div>
        <Sidebar />
        <section className="home-section">
          <div className="home-content">
            <i
              className="bx bx-menu"
              onClick={() => {
                dispatch(toggleSideMenu());
              }}
            ></i>
            <span className="text">Drop Down Sidebar</span>
          </div>
          <div className="container-fluid">
            <div className="content pb-0">
              {isFullScreenLoading && <FullScreenLoader />}
              <Routers />
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};
