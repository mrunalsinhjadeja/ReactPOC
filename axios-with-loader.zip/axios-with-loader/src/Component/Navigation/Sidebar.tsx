import { NavLink, useLocation } from "react-router-dom";
import "../../Sidebar.css";
import SidebarItems from "./SidebarItems";
import { useEffect, useState } from "react";
import React from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  setActiveParentLinkIndex,
  setActiveChildLinkIndex,
} from "../../Redux/Common/slice";
import app_configuration from "../../Helpers/APP_CONSTANT";
export const Sidebar = () => {
  const dispatch = useDispatch();
  const location = useLocation();
  const [activeParentIndex, setParentIndex] = useState<number>(-1);
  const [activeChildIndex, setChildIndex] = useState<number>(-1);

  let IsChildLinkClicked: boolean = false;

  const activeParentLinkIndex: number = useSelector(
    (state: any) => state.commonSlice.activeParentLinkIndex
  );

  const activeChildLinkIndex: number = useSelector(
    (state: any) => state.commonSlice.activeChildLinkIndex
  );

  useEffect(() => {
    debugger;
    let pIndex = -1;
    let cIndex = -1;
    if (location.pathname.split("/").length > 2) {
      const routChild: any = SidebarItems.filter(
        (x) => x.routeName === location.pathname.split("/")[1]
      ).map((ch) => ch.childMenu)[0];
      console.log("routChild :: ", routChild);
      const child = routChild.filter((x: any) => x.route === location.pathname);
      console.log("child :: ", child);
      pIndex = child[0].parentIndex;
      cIndex = child[0].childIndex;
    }
    dispatch(setActiveParentLinkIndex(pIndex));
    dispatch(setActiveChildLinkIndex(cIndex));
    setParentIndex(pIndex);
    setChildIndex(cIndex);
  }, [location]);

  const handleParentLinkIndexChange = (index: any) => {
    if (!IsChildLinkClicked) {
      setParentIndex(index);
      if (activeParentLinkIndex !== index) {
        setChildIndex(-1);
      } else {
        setChildIndex(activeChildLinkIndex);
      }
    }
  };

  const handleChildLinkIndexChange = (childIndex: any, parentIndex: any) => {
    dispatch(setActiveParentLinkIndex(parentIndex));
    dispatch(setActiveChildLinkIndex(childIndex));
    setParentIndex(parentIndex);
    setChildIndex(childIndex);
    IsChildLinkClicked = true;
  };

  const toggleSideMenu: string = useSelector(
    (state: any) => state.commonSlice.activeSidebarClassName
  );

  return (
    <div className={toggleSideMenu}>
      <div className="logo-details">
        <i className="bx bxl-c-plus-plus"></i>
        <span className="logo_name">{app_configuration.APP_NAME}</span>
      </div>
      <ul className="nav-links">
        {SidebarItems.map((item, parentIndex) => {
          return (
            <React.Fragment key={item.name}>
              {item.childMenu ? (
                <li
                  className={
                    parentIndex === activeParentIndex ? "showMenu" : ""
                  }
                  onClick={() => handleParentLinkIndexChange(parentIndex)}
                >
                  <>
                    <div className="iocn-link">
                      <NavLink to="#">
                        <i className="bx bx-collection"></i>
                        <span className="link_name">{item.name}</span>
                      </NavLink>
                      <i className="bx bxs-chevron-down arrow"></i>
                    </div>
                    <ul className="sub-menu">
                      <li>
                        <NavLink className="link_name" to="#">
                          {item.name}
                        </NavLink>
                      </li>
                      {item.childMenu.map((item: any, childIndex: any) => {
                        return (
                          <li key={item.name}>
                            <NavLink
                              className={
                                childIndex === activeChildIndex &&
                                parentIndex === activeParentIndex
                                  ? "nav-link active"
                                  : ""
                              }
                              to={item.route}
                              onClick={() => {
                                handleChildLinkIndexChange(
                                  childIndex,
                                  parentIndex
                                );
                              }}
                            >
                              {item.name}
                            </NavLink>
                          </li>
                        );
                      })}
                    </ul>
                  </>
                </li>
              ) : (
                <li
                  onClick={() => {
                    setParentIndex(-1);
                    setChildIndex(-1);
                    dispatch(setActiveParentLinkIndex(-1));
                    dispatch(setActiveChildLinkIndex(-1));
                  }}
                >
                  <NavLink to={item.route}>
                    <i className={item.iconClass}></i>
                    <span className="link_name">{item.name}</span>
                  </NavLink>
                </li>
              )}
            </React.Fragment>
          );
        })}
      </ul>
    </div>
  );
};
