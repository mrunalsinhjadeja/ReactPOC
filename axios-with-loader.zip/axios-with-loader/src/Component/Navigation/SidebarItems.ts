const SidebarItems = [
  {
    name: "Dashboard",
    route: "/",
    iconClass: "bx bx-grid-alt",
    routeName: "",
    parentIndex: 0,
  },
  {
    name: "Employee",
    route: "/employee",
    iconClass: "bx bxs-user",
    routeName: "",
    parentIndex: 1,
  },
  {
    name: "Parent",
    route: "#",
    iconClass: "bx bxs-user",
    routeName: "parent-one",
    parentIndex: 2,
    childMenu: [
      {
        name: "P1-child-one",
        route: "/parent-one/child-one",
        parentIndex: 2,
        childIndex: 0,
      },
      {
        name: "P1-child-two",
        route: "/parent-one/child-two",
        parentIndex: 2,
        childIndex: 1,
      },
    ],
  },
  {
    name: "Parent two",
    route: "#",
    iconClass: "bx bxs-user",
    routeName: "parent-two",
    parentIndex: 3,
    childMenu: [
      {
        name: "P2-child-one",
        route: "/parent-two/child-one",
        childIndex: 0,
        parentIndex: 3,
      },
      {
        name: "P2-child-two",
        route: "/parent-two/child-two",
        childIndex: 1,
        parentIndex: 3,
      },
    ],
  },
];

export default SidebarItems;
