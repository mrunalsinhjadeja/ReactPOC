import { Route, Routes } from "react-router-dom";
import { Dashboard } from "../../Pages/Dashboard/Dashboard";
import { Employee } from "../../Pages/Employee/Employee";
import { PoneChildone } from "../../Pages/Parent/PoneChildone";
import { PoneChildtwo } from "../../Pages/Parent/PoneChildtwo";
import { PtwoChildone } from "../../Pages/Parent-two/PtwoChildone";
import { PtwoChildtwo } from "../../Pages/Parent-two/PtwoChildtwo";

export const Routers: React.FC = () => {
  return (
    <>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/employee" element={<Employee />} />
        <Route path="/parent-one/child-one" element={<PoneChildone />} />
        <Route path="/parent-one/child-two" element={<PoneChildtwo />} />
        <Route path="/parent-two/child-one" element={<PtwoChildone />} />
        <Route path="/parent-two/child-two" element={<PtwoChildtwo />} />
      </Routes>
    </>
  );
};
