import { NavLink } from "react-router-dom";

export const ChildItemHeader = (props: { Title: string }) => {
  const title = props.Title;
  return (
    <div className="iocn-link">
      <NavLink to="#">
        <i className="bx bx-collection"></i>
        <span className="link_name">{title}</span>
      </NavLink>
      <i className="bx bxs-chevron-down arrow"></i>
    </div>
  );
};
