import { IEmployeeList } from "./Employee";

export default interface EmployeeListPropType {
  EmpTblList: IEmployeeList[];
}
