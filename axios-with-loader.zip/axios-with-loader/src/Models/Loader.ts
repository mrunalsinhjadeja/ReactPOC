export interface LoaderModel {
  readonly isLoading: boolean;
}
